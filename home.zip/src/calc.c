#include "functions.h"
int main(int argc, char* argv[]){
    char input;
    printf("Cursed Calculator\n");
    user_command();

}

